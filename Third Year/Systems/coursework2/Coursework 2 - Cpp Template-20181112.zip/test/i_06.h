#ifndef _I_06_H_
#define _I_06_H_

#include "i_11.h"
#include "i_05.h"
#include <pthread.h>

#endif /* _I_06_H_ */
