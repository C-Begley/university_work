#ifndef _ISPRIME_INCLUDED_
#define _ISPRIME_INCLUDED_

int is_prime(unsigned long number);

#endif /* _ISPRIME_INCLUDED_ */
