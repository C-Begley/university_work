module Main where
import HDL.Hydra.Core.Lib
import TrafficLight

main :: IO ()
main =
  do
    runTrafficLight1 test_data1
    runTrafficLight2 test_data2

runTrafficLight1 :: [[Int]] -> IO ()

test_data1:: [[Int]]

test_data1 =
-- input       expected outputs
-- reset       g  a  r
  [[1,         0, 0, 0],
   [0,         1, 0, 0],
   [0,         1, 0, 0],
   [0,         1, 0, 0],
   [0,         0, 1, 0],
   [0,         0, 0, 1],
   [0,         0, 0, 1],
   [0,         0, 0, 1],
   [0,         0, 0, 1],
   [0,         0, 1, 0],
   [0,         1, 0, 0],
   [0,         1, 0, 0],
   [0,         1, 0, 0],
   [0,         0, 1, 0],
   [0,         0, 0, 1],
   [1,         0, 0, 1],
   [0,         1, 0, 0],
   [0,         1, 0, 0],
   [0,         1, 0, 0],
   [0,         0, 1, 0]
  ]

runTrafficLight1 input =
  do
    putStrLn "\n       runTrafficLight1"
    putStrLn "input │     traffic     │ "
    putStrLn "reset │ green amber red │ Testing"
    putStrLn "──────┼─────────────────┼────────"
    runAllInput input output
  where
    reset = getbit input 0
    (g,a,r) = controller1 reset

    -- Internal signals used to verify actual output against expected output
    green_correct = xnor2 (g) (getbit input 1)
    amber_correct = xnor2 (a) (getbit input 2)
    red_correct   = xnor2 (r) (getbit input 3)
    -- Overall pass/fail signal to indicate if all "tests" pass
    correct = green_correct `and2` amber_correct `and2` red_correct

    output =
      [string "    ", bit reset,
       string " │     ", bit g,
       string "     ", bit a,
       string "   ", bit r,
       string " │ ", bit correct,
       string " (", bit green_correct,
       bit amber_correct,
       bit red_correct,
       string ")"
       ]


runTrafficLight2 :: [[Int]] -> IO ()

test_data2:: [[Int]]

test_data2=
-- inputs          expected outputs
-- reset wkreq     g  a  r  wt  wk (walkCount has been omitted)
 [[1,    0,        0, 0, 0, 0,  0],
  [0,    0,        1, 0, 0, 1,  0],
  [0,    1,        1, 0, 0, 1,  0],
  [0,    0,        0, 1, 0, 1,  0],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 1, 0, 1,  0],
  [0,    0,        1, 0, 0, 1,  0],
  [0,    0,        1, 0, 0, 1,  0],
  [0,    0,        1, 0, 0, 1,  0],
  [0,    1,        1, 0, 0, 1,  0],
  [0,    0,        0, 1, 0, 1,  0],
  [0,    1,        0, 0, 1, 0,  1],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 1, 0, 1,  0],
  [0,    0,        1, 0, 0, 1,  0],
  [0,    1,        1, 0, 0, 1,  0],
  [1,    0,        0, 1, 0, 1,  0],
  [0,    0,        1, 0, 0, 1,  0],
  [0,    1,        1, 0, 0, 1,  0],
  [0,    1,        0, 1, 0, 1,  0],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 0, 1, 0,  1],
  [0,    0,        0, 1, 0, 1,  0],
  [0,    0,        1, 0, 0, 1,  0]
 ]

runTrafficLight2 input =
  do
    putStrLn "\n                          runTrafficLight2"
    putStrLn "   inputs   │     traffic     ┆    ped.   ┆  internal signal  │ "
    putStrLn "reset wkreq │ green amber red ┆ wait walk ┆        walk-count │ Testing"
    putStrLn "────────────┼─────────────────┼───────────┼───────────────────┼────────"
    runAllInput input output
     where
       reset = getbit input 0
       walkRequest = getbit input 1
       (g,a,r,wt,wk,wc) = controller2 reset walkRequest

       -- Internal signals used to verify actual output against expected output
       green_correct = xnor2 (g) (getbit input 2)
       amber_correct = xnor2 (a) (getbit input 3)
       red_correct   = xnor2 (r) (getbit input 4)
       wait_correct  = xnor2 (wt) (getbit input 5)
       walk_correct  = xnor2 (wk) (getbit input 6)
       -- Overall pass/fail signal to indicate if all "tests" pass
       correct = green_correct `and2` amber_correct `and2` red_correct `and2` wait_correct `and2` walk_correct

       output =
         [string "    ", bit reset,
          string "     ", bit walkRequest,
          string " │     ", bit g,
          string "     ", bit a,
          string "   ", bit r,
          string " ┆    ", bit wt,
          string "    ", bit wk,
          string " ┆  ", bindec 16 wc,
          string " │ ", bit correct,
          string " (", bit green_correct,
          bit amber_correct,
          bit red_correct,
          bit wait_correct,
          bit walk_correct, string ")"
          ]
