module TrafficLight where

import HDL.Hydra.Core.Lib
import HDL.Hydra.Circuits.Combinational


controller1 :: CBit a => a -> (a,a,a)
-- ^ State machine for the predefined list of states
controller1 reset = (green,amber,red)
 where
    reset' = inv reset -- internal signal

    -- The states
    gr0 = dff (or2 reset am1)
    gr1 = dff (and2 reset' gr0)
    gr2 = dff (and2 reset' gr1)
    am0 = dff (and2 reset' gr2)
    rd0 = dff (and2 reset' am0)
    rd1 = dff (and2 reset' rd0)
    rd2 = dff (and2 reset' rd1)
    rd3 = dff (and2 reset' rd2)
    am1 = dff (and2 reset' rd3)
    
    -- The machine outputs (derived from the current state)
    green = or3 gr0 gr1 gr2
    amber = or2 am0 am1
    red = or4 rd0 rd1 rd2 rd3


count4 :: CBit a => a -> a -> (a, [a])
-- ^ Four bit counter with a synchronous reset and enable
count4 reset incr = (c0, [x0, x1, x2, x3])
  where
    x0 = dff (mux1 reset y0 zero)
    x1 = dff (mux1 reset y1 zero)
    x2 = dff (mux1 reset y2 zero)
    x3 = dff (mux1 reset y3 zero)
    (c0,y0) = halfAdd x0  c1
    (c1,y1) = halfAdd x0  c2
    (c2,y2) = halfAdd x2  c3
    (c3,y3) = halfAdd x3  incr


count16 :: CBit a => a -> a -> (a, [a])
-- ^ Sixteen bit counter with a synchronous reset and enable (built using four four-bit counters)
count16 reset incr = (ovfl0, [x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15])
  where
    (ovfl0, [x0, x1, x2, x3])     = count4 reset ovfl1
    (ovfl1, [x4, x5, x6, x7])     = count4 reset ovfl2
    (ovfl2, [x8, x9, x10, x11])   = count4 reset ovfl3
    (ovfl3, [x12, x13, x14, x15]) = count4 reset incr


controller2 :: CBit a => a -> a -> (a,a,a,a,a,[a])
{- ^ State machine which goes through a predifned list of states when a `walkRequest` signal is given.
     If `walkRequest` is high, whilst the system is outputting green, a walk cycle is initiated.
     The value of `walkCount` is incremented for every clock cycle where `walkRequest` is high.
-}
controller2 reset walkRequest = (green,amber,red,wait,walk,walkCount)
 where
    reset' = inv reset -- an internal signal

    -- The states
    green = dff (or3 reset amber2 (and2 (inv walkRequest) green))
    amber1 = dff (and3 reset' walkRequest green)
    red1 = dff (and2 reset' amber1)
    red2 = dff (and2 reset' red1)
    red3 = dff (and2 reset' red2)
    amber2 = dff (and2 reset' red3)

    -- The machine outputs (derived from the current state)
    amber = or2 amber1 amber2
    red = or3 red1 red2 red3
    wait = or3 green amber1 amber2
    walk = red
    (overflow, walkCount) = count16 reset walkRequest
