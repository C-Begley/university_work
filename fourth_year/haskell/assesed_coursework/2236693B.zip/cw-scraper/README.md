# cw-scraper

This is a skeleton Stack project for the Functional Programming coursework exercise in Glasgow, Nov 2019. For full details, please refer to the course moodle page at
https://moodle.gla.ac.uk/course/view.php?id=978

---
Jeremy.Singer@glasgow.ac.uk
18 Nov 2019
